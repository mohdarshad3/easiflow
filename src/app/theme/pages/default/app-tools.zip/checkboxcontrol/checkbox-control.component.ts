import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'checkbox-control',
    templateUrl: './checkbox-control.component.html',
    styleUrls: ['./checkbox-control.component.css']
})
export class CheckboxControlComponent {
   
    
}