import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'radio-control',
    templateUrl: './radio-control.component.html',
    styleUrls: ['./radio-control.component.css']
})
export class RadioControlComponent {
   
    
}