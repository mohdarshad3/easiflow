import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'dropdown-control',
    templateUrl: './dropdown-control.component.html',
    styleUrls: ['./dropdown-control.component.css']
})
export class DropdownControlComponent {
   
    
}