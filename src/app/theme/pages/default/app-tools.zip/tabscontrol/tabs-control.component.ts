import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'tabs-control',
    templateUrl: './tabs-control.component.html',
    styleUrls: ['./tabs-control.component.css']
})
export class TabsControlComponent {
   
    
}