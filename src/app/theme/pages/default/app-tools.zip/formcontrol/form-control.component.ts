import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'form-control',
    templateUrl: './form-control.component.html',
    styleUrls: ['./form-control.component.css']
})
export class FormControlComponent {
   
    
}