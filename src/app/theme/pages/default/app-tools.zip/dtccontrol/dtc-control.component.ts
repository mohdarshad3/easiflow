import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'dtc-control',
    templateUrl: './dtc-control.component.html',
    styleUrls: ['./dtc-control.component.css']
})
export class DTCControlComponent {
   
    
}