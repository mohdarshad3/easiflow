import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'divider-control',
    templateUrl: './divider-control.component.html',
    styleUrls: ['./divider-control.component.css']
})
export class DividerControlComponent {
   
    
}