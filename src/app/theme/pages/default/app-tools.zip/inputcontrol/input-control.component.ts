import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'input-control',
    templateUrl: './input-control.component.html',
    styleUrls: ['./input-control.component.css']
})
export class InputControlComponent {
   
    
}