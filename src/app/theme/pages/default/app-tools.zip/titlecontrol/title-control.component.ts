import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'title-control',
    templateUrl: './title-control.component.html',
    styleUrls: ['./title-control.component.css']
})
export class TitleControlComponent {
   
    
}