import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'button-control',
    templateUrl: './button-control.component.html',
    styleUrls: ['./button-control.component.css']
})
export class ButtonControlComponent {
   
    
}