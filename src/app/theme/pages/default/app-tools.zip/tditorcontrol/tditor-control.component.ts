import { Component } from '@angular/core';

@Component({
    selector: 'tditor-control',
    templateUrl: './tditor-control.component.html',
    styleUrls: ['./tditor-control.component.css']
})
export class TditorControlComponent {
   
    
}