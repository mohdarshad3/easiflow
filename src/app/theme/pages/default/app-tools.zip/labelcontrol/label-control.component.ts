import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'label-control',
    templateUrl: './label-control.component.html',
    styleUrls: ['./label-control.component.css']
})
export class LabelControlComponent {
   
    
}