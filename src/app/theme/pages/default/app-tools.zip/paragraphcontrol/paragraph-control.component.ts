import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'paragraph-control',
    templateUrl: './paragraph-control.component.html',
    styleUrls: ['./paragraph-control.component.css']
})
export class ParagraphControlComponent {
   
    
}