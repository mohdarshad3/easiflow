import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'anchor-control',
    templateUrl: './anchor-control.component.html',
    styleUrls: ['./anchor-control.component.css']
})
export class AnchorControlComponent {
   
    
}