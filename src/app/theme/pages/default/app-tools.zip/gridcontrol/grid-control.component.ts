import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'grid-control',
    templateUrl: './grid-control.component.html',
    styleUrls: ['./grid-control.component.css']
})
export class GridControlComponent {
   
    
}