import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
    selector: 'dtp-control',
    templateUrl: './dtp-control.component.html',
    styleUrls: ['./dtp-control.component.css']
})
export class DTPControlComponent {
   
    
}